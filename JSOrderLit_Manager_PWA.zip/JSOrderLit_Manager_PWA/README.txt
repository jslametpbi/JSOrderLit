# JSOrderLit Manager

Professional no-API-key web/PWA app for article project order management.

## Features
- Project order dashboard
- Article/project records
- Authors and corresponding author
- Target journal and Scopus category
- Price and payment terms
- Invoice creation and printing
- Receipt creation and printing
- CSV export
- Search and filters
- Permanent browser storage using localStorage
- Installable as PWA on desktop/mobile

## How to publish for a permanent link, no API key

### Easiest: Netlify Drop
1. Open https://app.netlify.com/drop
2. Drag the entire folder `JSOrderLit_Manager_PWA` into the page
3. Netlify will give you a permanent public link
4. No API key is needed

### Alternative: GitHub Pages
1. Create a GitHub repository
2. Upload all files in this folder
3. Enable GitHub Pages from Settings > Pages
4. Select the main branch and root folder
5. GitHub will provide a permanent link

## Important data note
This version stores data in the browser using localStorage. It is permanent on the same browser/device unless the browser data is cleared. For multi-device access, team access, or cloud backup, connect a database later.
